import pandas as pd
import joblib
import os
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, f1_score
from fitur import bersihkan_dan_buat_fitur

df = pd.read_csv('kasus07_pima_diabetes.csv')
df = bersihkan_dan_buat_fitur(df)

X = df.drop('type', axis=1)
y = df['type']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

pipe_rf = Pipeline([
    ('imputer', SimpleImputer(strategy='median')),
    ('model', RandomForestClassifier(random_state=42))
])

pipe_rf.fit(X_train, y_train)

y_pred = pipe_rf.predict(X_test)

os.makedirs('models', exist_ok=True)
joblib.dump(pipe_rf, 'models/pima_diabetes_model.joblib')

metadata = {
    'accuracy': accuracy_score(y_test, y_pred),
    'f1_score': f1_score(y_test, y_pred)
}
joblib.dump(metadata, 'models/metadata.joblib')
print("Model berhasil dilatih dan disimpan di folder models/")