import pandas as pd
import numpy as np

def bersihkan_dan_buat_fitur(df):
    df_clean = df.copy()
    kolom_medis = ['glu', 'bp', 'skin', 'bmi']
    
    df_clean[kolom_medis] = df_clean[kolom_medis].replace(0, np.nan)
    
    df_clean['glu_bmi'] = df_clean['glu'] * df_clean['bmi']
    
    if 'type' in df_clean.columns:
        df_clean['type'] = df_clean['type'].map({'Yes': 1, 'No': 0})
        
    return df_clean