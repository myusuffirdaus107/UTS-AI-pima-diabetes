import streamlit as st
import pandas as pd
import joblib
import numpy as np

model = joblib.load('models/pima_diabetes_model.joblib')
metadata = joblib.load('models/metadata.joblib')

st.set_page_config(page_title="Prediksi Diabetes", layout="centered")

st.title("🏥 Aplikasi Prediksi Diabetes Pima")
st.write("Masukkan data medis pasien di bawah ini untuk memprediksi kemungkinan diabetes.")

with st.form("input_form"):
    st.subheader("Data Medis Pasien")
    col1, col2 = st.columns(2)
    
    with col1:
        preg = st.number_input("Jumlah Kehamilan (npreg)", min_value=0, max_value=20, value=1)
        glu = st.number_input("Kadar Glukosa (glu)", min_value=0, max_value=300, value=100)
        bp = st.number_input("Tekanan Darah (bp)", min_value=0, max_value=150, value=70)
        skin = st.number_input("Ketebalan Kulit (skin)", min_value=0, max_value=100, value=20)
        
    with col2:
        bmi = st.number_input("Indeks Massa Tubuh (bmi)", min_value=0.0, max_value=70.0, value=25.0)
        ped = st.number_input("Fungsi Silsilah (ped)", min_value=0.0, max_value=3.0, value=0.5)
        age = st.number_input("Usia (age)", min_value=1, max_value=100, value=30)
        
    submit_button = st.form_submit_button(label="Prediksi Sekarang")

if submit_button:
    input_data = pd.DataFrame({
        'npreg': [preg], 'glu': [glu], 'bp': [bp], 'skin': [skin],
        'bmi': [bmi], 'ped': [ped], 'age': [age]
    })
    
    input_data['glu_bmi'] = input_data['glu'] * input_data['bmi']
    
    med_cols = ['glu', 'bp', 'skin', 'bmi']
    input_data[med_cols] = input_data[med_cols].replace(0, np.nan)
    
    prediction = model.predict(input_data)[0]
    probability = model.predict_proba(input_data)[0]
    
    st.subheader("Hasil Prediksi:")
    if prediction == 1:
        st.error(f"⚠️ **Pasien Terindikasi Diabetes.** (Probabilitas: {probability[1]:.2%})")
    else:
        st.success(f"✅ **Pasien Terindikasi Sehat (Tidak Diabetes).** (Probabilitas Sehat: {probability[0]:.2%})")

st.sidebar.header("📊 Metrik Evaluasi Model")
st.sidebar.write(f"**Accuracy:** {metadata['accuracy']:.3f}")
st.sidebar.write(f"**F1-Score:** {metadata['f1_score']:.3f}")
st.sidebar.info("Model ini dilatih menggunakan algoritma Random Forest dengan Pipeline.")